package swexpert;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Solution {
	
    static int T;
    static int[] num;
	
	public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        int sum;
        T = sc.nextInt();
        int testCase = T;
        
        
		
        for(int z = 0; z < testCase; z++) {
        	
        	int student = sc.nextInt();
        	int number = sc.nextInt();
        	
			int[] score_list = new int[student];
			
			int number_score = 0;
			
			for(int i = 0; i < student; i++){
				int score = 0;
				score = sc.nextInt()*35 + sc.nextInt()*45 + sc.nextInt()*20;
				score_list[i] = score;
				if( i == number -1) {
					System.out.println(i);
					number_score = score;
				}
			}
			
			for(int j = 0; j < score_list.length; j++) {
				for(int i = j+1; i < score_list.length; i++) {
						if(score_list[j] < score_list[i]) {
							int temp = score_list[j];
							score_list[j] = score_list[i];
							score_list[i] = temp;
					}
				}
			}
			
			for(int j = 0; j < score_list.length; j++) {
                System.out.println(score_list[j]);
				if(score_list[j] == number_score) {
					number = j;
				}
			}
			
			
			
			String[] str_list2 = {"A+", "A0", "A-","B+", "B0", "B-","C+", "C0", "C-", "D0"};
			
            
			System.out.printf("#%d  ",z+1);
			System.out.println(number);
			int index = (number-1)*10/student;
			System.out.println(index);
//			System.out.println(index);
			System.out.println(str_list2[index]);
        }
		
	}

}