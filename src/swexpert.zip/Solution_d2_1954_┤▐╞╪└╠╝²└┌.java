package swexpert;

import java.util.Scanner;

public class Solution_d2_1954_달팽이숫자 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int tc = sc.nextInt();
		
		for(int i=1; i<=tc; i++) {
			int N = sc.nextInt();
			
			int[][] snail = new int[N][N];
			
			int number = 1;
			
			//snail 초기화
			
			for(int j=0; j<N; j++) {
				for(int k=0; k<N; k++) {
					snail[j][k] = number;
					number++;
				}
			}
			
			// 출력길이
			// N=3 3 2 2 1 1
			// 3 1 1 2/1 2/1 2/1 2/1
			// N=4 4 3 3 2 2 1 1
			// N=5 5 4 4 3 3 2 2 1 1
			//
			
			for(int j=0; j<N; j++) {
				for(int k=0; k<N; k++) {
					snail[j][k] = number;
					number++;
				}
			}
		}

	}

}
