package swexpert;

import java.util.Scanner;

public class Soultion_d2_1959_두개의숫자열 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int tc = sc.nextInt();
		
		
		
		for(int i=1; i<=tc; i++) {
			int N = sc.nextInt();
			int M = sc.nextInt();
			
			int[] arr1 = new int[N];
			int[] arr2 = new int[M];
			
			
			for(int j=0; j<N; j++) {
				arr1[j] = sc.nextInt();
			}
			
			for(int j=0; j<M; j++) {
				arr2[j] = sc.nextInt();
			}
			
			/***
			 * 받은 배열중에 어느 배열이 더 긴지 구분한다.
			 * 더 작은 배열을 움직여 가며 긴 배열과 곱한 값을
			 * 그 전 값과 계속해서 비교한다.
			 * 길이가 더 작은 배열은 인덱스가 고정되어있다.
			 */
		     int max = Integer.MIN_VALUE;
			
			 int[][] sum;
					 
			 if(N < M) {
				 sum = new int [M-N+1][M-N+1];
				 
				 for(int j=0; j<N; j++) {
					 for(int k=j; k<M-N+1+j; k++) {
						 sum[j][k-j] = arr1[j]*arr2[k];
					 }
				 }
				 
				 for(int j=0; j<M-N+1; j++) {
					 for(int k=0; k<M-N+1; k++) {
						 System.out.printf("%d ",sum[j][k]);
					 }
					 System.out.println();
				 }
				 
				 
				 
				 for(int j=0; j<M-N+1; j++) {
					 int sum3 = 0;
					 for(int k=0; k<M-N+1; k++) {
						 sum3 += sum[k][j];
					 }
					 if(max < sum3) {
						 max = sum3;
					 }
				 }
				 System.out.printf("#%d %d\n",i,max);
			 }else if(N > M){
				 sum = new int [N-M+1][N-M+1];
				 
				 for(int j=0; j<M; j++) {
					 for(int k=j; k<N-M+1; k++) {
						 sum[j][k-j] = arr1[j]*arr2[k];
					 }
				 }
				 
				 for(int j=0; j<N-M+1; j++) {
					 for(int k=0; k<N-M+1; k++) {
						 System.out.printf("%d ",sum[j][k]);
					 }
					 System.out.println();
				 }
				 
				 
				 for(int j=0; j<N-M+1; j++) {
					 int sum3 = 0;
					 for(int k=0; k<N-M+1; k++) {
						 sum3 += sum[k][j];
					 }
					 if(max < sum3) {
						 max = sum3;
					 }
				 }
				 System.out.printf("#%d %d\n",i,max);
			 }else {
				 int sum2 = 0;
				 
				 for(int j=0; j<N; j++) {
					 sum2 += arr1[j]*arr2[j];
				 }
				 
				 System.out.printf("#%d %d\n",i,sum2);
			 }
			
		}

	}

}